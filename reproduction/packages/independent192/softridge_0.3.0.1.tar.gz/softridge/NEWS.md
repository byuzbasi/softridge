# softridge 0.3.0

* Added opt-in training least-squares rescaling to `hr()` and `cv_hr()`.
  Numerical path, scale and CV score calculations use RcppArmadillo.
* Added fixed positive scale arguments and oracle scale information to exact
  risk and SURE routines. These exact formulas apply to fixed tuning and a
  fixed scale, not a scale estimated from the same response.
* Preserved the default unscaled estimator and fold-local threshold fractions.
* Retained rank-aware minimum-norm least-squares refitting and documented
  explicit absolute grids for independent implementation comparison.
