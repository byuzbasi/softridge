#' Default tuning grids for the HR estimator
#'
#' The ridge grid is geometric between \code{kmin_ratio * d1^2} and
#' \code{d1^2}, where \code{d1} is the largest singular value of the prepared
#' design. For each ridge value the threshold grid is
#' \code{c * max|ridge|}, \code{c} in \code{[0, 0.99]}.
#'
#' @param X design matrix.
#' @param y response.
#' @param nk number of ridge values.
#' @param ng number of threshold values.
#' @param kmin_ratio smallest ridge value relative to the squared leading
#'   singular value.
#' @param intercept,standardize passed to the design preparation.
#' @return A list with the vector \code{k} and the matrix \code{gamma}
#'   (\code{nk x ng}), one row of thresholds per ridge value.
#' @export
hr_grid <- function(X, y, nk = 12, ng = 40, kmin_ratio = 1e-4,
                    intercept = TRUE, standardize = TRUE) {
  pr <- .prep_design(X, y, intercept, standardize)
  sv <- .svd_design(pr$X)
  k <- sv$d[1]^2 * exp(seq(log(kmin_ratio), 0, length.out = nk))
  B <- ridge_path(pr$X, pr$y, k, sv)
  cgrid <- seq(0, 0.99, length.out = ng)
  gamma <- t(sapply(seq_len(nk), function(i) cgrid * max(abs(B[, i]))))
  list(k = k, gamma = gamma)
}

#' Cross-validated HR estimator
#'
#' Selects the ridge parameter and the threshold by K-fold cross-validation of
#' the prediction error. With \code{refit = TRUE}, the variables retained by
#' thresholding are refitted by least squares and the pair (ridge parameter,
#' model size) is selected instead; model size \code{m} corresponds to the
#' data-dependent threshold equal to the \code{(m+1)}-th largest absolute
#' ridge coefficient. With \code{scale = TRUE} the scaled HR estimator is
#' tuned instead: for every pair of tuning values the thresholded vector is
#' multiplied by its scale factor (see \code{hr}), computed on the training
#' part of each fold. The corrected scale needs an estimate of the error
#' variance. It may be a single value used in every fold, or, preferably, a
#' vector of fold-specific estimates computed from the training part of each
#' fold only, as returned by \code{fold_variance}, so that the held-out
#' responses never enter the scale used to predict them.
#'
#' @param X design matrix.
#' @param y response.
#' @param nfolds number of folds.
#' @param grid output of \code{hr_grid}; computed on the full data if missing.
#' @param refit logical, least-squares refit on the selected variables.
#' @param max_size largest model size considered when \code{refit = TRUE}.
#' @param foldid optional fold assignment.
#' @param intercept,standardize passed to the design preparation.
#' @param scale logical, tune the scaled HR estimator; not available together
#'   with \code{refit = TRUE}.
#' @param scale_type \code{"corrected"} (default) or \code{"ls"}.
#' @param sigma2 error variance or an estimate of it, required for the
#'   corrected scale. Either one value, or a vector of length
#'   \code{max(foldid) + 1} whose element \code{f} is used on the training
#'   part of fold \code{f} and whose last element is used for the final fit
#'   on the full data.
#' @param zero_threshold logical, restrict the threshold to zero, which gives
#'   scaled ridge regression (used as a control).
#' @return A list with the selected tuning values, the cross-validation error
#'   surface, the final coefficient vector \code{coef} (intercept first), the
#'   scale factor \code{scale} of the final fit (one unless
#'   \code{scale = TRUE}) and the selected index set \code{selected}.
#' @examples
#' set.seed(1)
#' X <- matrix(rnorm(60 * 150), 60, 150)
#' y <- X[, 1:3] %*% c(3, -2, 1.5) + rnorm(60)
#' cv <- cv_hr(X, y, nfolds = 5)
#' cv$selected
#' @export
cv_hr <- function(X, y, nfolds = 10, grid = NULL, refit = FALSE,
                  max_size = NULL, foldid = NULL, intercept = TRUE,
                  standardize = TRUE, scale = FALSE,
                  scale_type = c("corrected", "ls"), sigma2 = NULL,
                  zero_threshold = FALSE) {
  scale_type <- match.arg(scale_type)
  if (refit && scale) stop("use either refit = TRUE or scale = TRUE")
  if (scale && scale_type == "corrected" && is.null(sigma2))
    stop("sigma2 is required for the corrected scale")
  X <- as.matrix(X); y <- drop(y); n <- nrow(X); p <- ncol(X)
  if (is.null(grid)) grid <- hr_grid(X, y, intercept = intercept,
                                     standardize = standardize)
  if (is.null(foldid)) foldid <- sample(rep(seq_len(nfolds), length.out = n))
  nfolds <- max(foldid)
  if (!is.null(sigma2)) {
    if (length(sigma2) == 1) sigma2 <- rep(sigma2, nfolds + 1)
    if (length(sigma2) != nfolds + 1 || any(!is.finite(sigma2)) || any(sigma2 < 0))
      stop("sigma2 must be one nonnegative value or a vector of length max(foldid) + 1")
  }
  k <- grid$k
  if (zero_threshold) grid$gamma <- matrix(0, length(k), 1)
  if (refit) {
    if (is.null(max_size)) max_size <- min(floor(0.5 * n), p)
    err <- matrix(0, length(k), max_size)
  } else {
    err <- matrix(0, length(k), ncol(grid$gamma))
  }
  for (f in seq_len(nfolds)) {
    tr <- foldid != f
    pr <- .prep_design(X[tr, , drop = FALSE], y[tr], intercept, standardize)
    sv <- .svd_design(pr$X)
    B <- ridge_path(pr$X, pr$y, k, sv)
    Xte <- sweep(sweep(X[!tr, , drop = FALSE], 2, pr$xm, "-"), 2, pr$xs, "/")
    yte <- y[!tr] - pr$ym
    for (i in seq_along(k)) {
      if (refit) {
        ord <- order(abs(B[, i]), decreasing = TRUE)
        for (m in seq_len(max_size)) {
          S <- ord[seq_len(m)]
          cf <- tryCatch(qr.coef(qr(pr$X[, S, drop = FALSE]), pr$y),
                         error = function(e) rep(NA, m))
          cf[is.na(cf)] <- 0
          err[i, m] <- err[i, m] + sum((yte - Xte[, S, drop = FALSE] %*% cf)^2)
        }
      } else {
        Th <- matrix(sapply(grid$gamma[i, ], function(g) soft_threshold(B[, i], g)),
                     nrow = p)
        if (scale) {
          ad <- drop((sv$v^2) %*% (sv$d^2 / (sv$d^2 + k[i])))
          Th <- sweep(Th, 2, .scale_of(scale_type, pr$X, pr$y, Th, ad, sigma2[f]), "*")
        }
        err[i, ] <- err[i, ] + colSums((yte - Xte %*% Th)^2)
      }
    }
  }
  err <- err / n
  best <- which(err == min(err), arr.ind = TRUE)[1, ]
  pr <- .prep_design(X, y, intercept, standardize)
  sv <- .svd_design(pr$X)
  b <- drop(ridge_path(pr$X, pr$y, k[best[1]], sv))
  cc <- 1
  if (refit) {
    S <- sort(order(abs(b), decreasing = TRUE)[seq_len(best[2])])
    th <- numeric(p)
    cf <- qr.coef(qr(pr$X[, S, drop = FALSE]), pr$y); cf[is.na(cf)] <- 0
    th[S] <- cf
    gamma_sel <- if (best[2] < p) sort(abs(b), decreasing = TRUE)[best[2] + 1] else 0
  } else {
    gamma_sel <- grid$gamma[best[1], best[2]]
    th <- soft_threshold(b, gamma_sel)
    if (scale) {
      ad <- drop((sv$v^2) %*% (sv$d^2 / (sv$d^2 + k[best[1]])))
      cc <- .scale_of(scale_type, pr$X, pr$y, th, ad, sigma2[nfolds + 1])
      th <- cc * th
    }
  }
  beta <- th / pr$xs
  a0 <- pr$ym - sum(beta * pr$xm)
  list(k = k[best[1]], gamma = gamma_sel, scale = cc,
       size = if (refit) best[2] else sum(th != 0),
       cv_error = err, min_error = min(err), grid = grid, foldid = foldid,
       coef = c(a0, beta), selected = which(beta != 0), refit = refit,
       sigma2 = sigma2)
}

#' Fold-specific estimates of the error variance
#'
#' Applies a variance estimator to the training part of every fold and to
#' the full data. Inside fold \code{f} the estimator receives the training
#' observations together with their own fold labels, relabelled
#' \code{1, ..., max(foldid) - 1}, so that any cross-validation it performs
#' uses the remaining folds as inner folds and never touches the held-out
#' observations.
#'
#' @param X design matrix.
#' @param y response.
#' @param foldid fold assignment with values \code{1, ..., K}.
#' @param estimator function of \code{(X, y, foldid)} returning one
#'   nonnegative variance estimate, for instance the residual mean square of
#'   a cross-validated lasso fit.
#' @return A vector of length \code{K + 1}, the estimate on the training part
#'   of each fold followed by the estimate on the full data, suitable as the
#'   \code{sigma2} argument of \code{cv_hr}.
#' @examples
#' set.seed(1)
#' X <- matrix(rnorm(60 * 100), 60, 100)
#' y <- X[, 1:3] %*% c(3, -2, 1.5) + rnorm(60)
#' fid <- rep(1:5, length.out = 60)
#' rms <- function(X, y, foldid) {
#'   f <- lm.fit(cbind(1, X[, 1:3]), y)
#'   sum(f$residuals^2) / (length(y) - 4)
#' }
#' fold_variance(X, y, fid, rms)
#' @export
fold_variance <- function(X, y, foldid, estimator) {
  X <- as.matrix(X); y <- drop(y); K <- max(foldid)
  if (!all(sort(unique(foldid)) == seq_len(K)) || K < 2)
    stop("foldid must take the values 1, ..., K with K >= 2")
  out <- numeric(K + 1)
  for (f in seq_len(K)) {
    tr <- foldid != f
    inner <- match(foldid[tr], sort(unique(foldid[tr])))
    out[f] <- estimator(X[tr, , drop = FALSE], y[tr], inner)
  }
  out[K + 1] <- estimator(X, y, foldid)
  if (any(!is.finite(out)) || any(out < 0)) stop("the estimator returned an invalid value")
  out
}

#' HR estimator tuned by the Stein unbiased risk estimate
#'
#' Minimizes the unbiased risk estimate of \code{hr_sure} over the grid.
#'
#' @param X design matrix.
#' @param y response.
#' @param sigma2 error variance or an estimate of it.
#' @param grid output of \code{hr_grid}; computed if missing.
#' @param intercept,standardize passed to the design preparation.
#' @return A list with the selected tuning values, the fitted coefficients
#'   (intercept first), the selected set and the degrees of freedom.
#' @export
sure_hr <- function(X, y, sigma2, grid = NULL, intercept = TRUE,
                    standardize = TRUE) {
  X <- as.matrix(X); y <- drop(y)
  if (is.null(grid)) grid <- hr_grid(X, y, intercept = intercept,
                                     standardize = standardize)
  pr <- .prep_design(X, y, intercept, standardize)
  sv <- .svd_design(pr$X)
  n <- nrow(X)
  best <- c(Inf, NA, NA); dfb <- NA
  B <- ridge_path(pr$X, pr$y, grid$k, sv)
  for (i in seq_along(grid$k)) {
    akdiag <- drop((sv$v^2) %*% (sv$d^2 / (sv$d^2 + grid$k[i])))
    Th <- sapply(grid$gamma[i, ], function(g) soft_threshold(B[, i], g))
    rss <- colSums((pr$y - pr$X %*% Th)^2)
    df <- colSums((Th != 0) * akdiag) + intercept
    sure <- rss - n * sigma2 + 2 * sigma2 * df
    j <- which.min(sure)
    if (sure[j] < best[1]) { best <- c(sure[j], i, j); dfb <- df[j] }
  }
  kk <- grid$k[best[2]]; gg <- grid$gamma[best[2], best[3]]
  b <- drop(ridge_path(pr$X, pr$y, kk, sv))
  beta <- soft_threshold(b, gg) / pr$xs
  a0 <- pr$ym - sum(beta * pr$xm)
  list(k = kk, gamma = gg, sure = best[1], df = dfb, coef = c(a0, beta),
       selected = which(beta != 0))
}
