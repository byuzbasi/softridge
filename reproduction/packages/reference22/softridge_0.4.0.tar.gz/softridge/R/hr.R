#' Soft-thresholding operator
#'
#' Componentwise soft thresholding, \code{sign(z) * pmax(abs(z) - gamma, 0)}.
#'
#' @param z numeric vector or matrix.
#' @param gamma nonnegative threshold.
#' @return An object of the same shape as \code{z}.
#' @examples
#' soft_threshold(c(-2, -0.5, 0.3, 1.7), 1)
#' @export
soft_threshold <- function(z, gamma) {
  if (any(gamma < 0)) stop("gamma must be nonnegative")
  sign(z) * pmax(abs(z) - gamma, 0)
}

## Centre (and optionally scale) the design; returns the transformed matrix
## together with the centring and scaling constants so that coefficients can
## be mapped back to the original scale.
.prep_design <- function(X, y, intercept, standardize) {
  X <- as.matrix(X)
  n <- nrow(X)
  if (length(y) != n) stop("length(y) must equal nrow(X)")
  xm <- if (intercept) colMeans(X) else rep(0, ncol(X))
  Xc <- sweep(X, 2, xm, "-")
  xs <- if (standardize) sqrt(colSums(Xc^2) / n) else rep(1, ncol(X))
  if (any(xs == 0)) stop("design has constant (zero-variance) columns")
  Xs <- sweep(Xc, 2, xs, "/")
  ym <- if (intercept) mean(y) else 0
  list(X = Xs, y = y - ym, xm = xm, xs = xs, ym = ym)
}

## Thin singular value decomposition of the prepared design. Only singular
## values above a relative tolerance are kept, so that V spans the row space
## of X exactly (up to numerical precision).
.svd_design <- function(X, tol = 1e-10) {
  s <- svd(X)
  keep <- s$d > tol * max(s$d)
  list(u = s$u[, keep, drop = FALSE], d = s$d[keep], v = s$v[, keep, drop = FALSE])
}

## Least-squares scale of thresholded coefficient vectors: for each column t
## of Th, the value c that minimizes ||y - c X t||^2, truncated at zero.
## A column with X t = 0 receives scale one.
.ls_scale <- function(X, y, Th) {
  Fit <- X %*% as.matrix(Th)
  den <- colSums(Fit^2)
  num <- drop(crossprod(Fit, y))
  ifelse(den > 0, pmax(num / pmax(den, .Machine$double.xmin), 0), 1)
}

## Optimism-corrected scale (Proposition 2(ii) of the paper): the minimizer of
## the unbiased risk estimate, (y'X t - sigma2 * df) / ||X t||^2 with
## df = sum of the ridge leverages (A_k)_jj over the selected coordinates,
## truncated at zero. ad is the vector of leverages (A_k)_jj.
.corrected_scale <- function(X, y, Th, ad, sigma2) {
  Th <- as.matrix(Th)
  Fit <- X %*% Th
  den <- colSums(Fit^2)
  num <- drop(crossprod(Fit, y)) - sigma2 * colSums((Th != 0) * ad)
  ifelse(den > 0, pmax(num / pmax(den, .Machine$double.xmin), 0), 1)
}

## Scale of type "corrected" or "ls" for the columns of Th.
.scale_of <- function(type, X, y, Th, ad, sigma2) {
  if (type == "ls") .ls_scale(X, y, Th) else .corrected_scale(X, y, Th, ad, sigma2)
}

#' Ridge regression path computed through the singular value decomposition
#'
#' Computes \eqn{(X^T X + k I_p)^{-1} X^T y = X^T (X X^T + k I_n)^{-1} y} for
#' every value in \code{k}. The singular value decomposition is computed once,
#' so each additional value of \code{k} costs \eqn{O(p r)} operations with
#' \eqn{r = rank(X)}.
#'
#' @param X prepared (centred/scaled) design matrix.
#' @param y prepared response.
#' @param k positive ridge parameters.
#' @param sv optional precomputed output of the internal SVD helper.
#' @return A \code{p x length(k)} matrix of ridge coefficients.
#' @keywords internal
ridge_path <- function(X, y, k, sv = NULL) {
  if (is.null(sv)) sv <- .svd_design(X)
  uty <- drop(crossprod(sv$u, y))
  sapply(k, function(kk) drop(sv$v %*% (sv$d / (sv$d^2 + kk) * uty)))
}

#' High-dimensional ridge shrinkage and selection (HR) estimator
#'
#' Fits the soft-thresholded ridge estimator
#' \eqn{\hat\theta_j = sign(\hat\beta_{k,j})(|\hat\beta_{k,j}| - \gamma)_+},
#' where \eqn{\hat\beta_k} is the ridge estimator with ridge parameter \code{k}.
#' The estimator has an explicit form and is valid for \eqn{p > n}.
#'
#' With \code{scale = TRUE} the thresholded vector is multiplied by a scale
#' factor that corrects the double shrinkage caused by ridge regression
#' followed by thresholding. The default \code{scale_type = "corrected"} uses
#' \eqn{c = (Y^T X\hat\theta - \sigma^2 \widehat{df}) / \|X\hat\theta\|^2},
#' the minimizer of the unbiased risk estimate, truncated at zero; it needs an
#' estimate \code{sigma2} of the error variance. \code{scale_type = "ls"} uses
#' the least-squares scale \eqn{Y^T X\hat\theta / \|X\hat\theta\|^2}, which
#' overfits when the signal is weak.
#'
#' @param X \code{n x p} design matrix.
#' @param y response vector of length \code{n}.
#' @param k ridge parameter(s), positive.
#' @param gamma threshold(s), nonnegative. Thresholds apply on the scale of the
#'   standardized design when \code{standardize = TRUE}.
#' @param intercept logical, fit an unpenalized intercept by centring.
#' @param standardize logical, scale columns of \code{X} to unit variance.
#' @param nonneg logical, use the nonnegative variant
#'   \eqn{(\hat\beta_{k,j} - \gamma)_+}.
#' @param scale logical, multiply the thresholded vector by a scale factor
#'   (the scaled HR estimator).
#' @param scale_type \code{"corrected"} (default) or \code{"ls"}.
#' @param sigma2 error variance or an estimate of it, required when
#'   \code{scale = TRUE} and \code{scale_type = "corrected"}.
#' @return An object of class \code{"hr"} containing the coefficient array
#'   \code{beta} of dimension \code{p x length(k) x length(gamma)} on the
#'   original scale, the intercepts \code{a0}, the scale factors \code{scale}
#'   (all equal to one unless \code{scale = TRUE}) and the tuning grids.
#' @examples
#' set.seed(1)
#' X <- matrix(rnorm(50 * 200), 50, 200)
#' y <- X[, 1:3] %*% c(3, -2, 1.5) + rnorm(50)
#' fit <- hr(X, y, k = 10, gamma = 0.1)
#' which(coef(fit)[-1] != 0)
#' @export
hr <- function(X, y, k, gamma, intercept = TRUE, standardize = TRUE,
               nonneg = FALSE, scale = FALSE,
               scale_type = c("corrected", "ls"), sigma2 = NULL) {
  scale_type <- match.arg(scale_type)
  if (scale && scale_type == "corrected" && is.null(sigma2))
    stop("sigma2 is required for the corrected scale")
  if (any(k <= 0)) stop("k must be positive")
  pr <- .prep_design(X, y, intercept, standardize)
  sv <- .svd_design(pr$X)
  B <- ridge_path(pr$X, pr$y, k, sv)
  p <- ncol(pr$X)
  beta <- array(0, c(p, length(k), length(gamma)))
  a0 <- matrix(0, length(k), length(gamma))
  sc <- matrix(1, length(k), length(gamma))
  for (g in seq_along(gamma)) {
    Th <- if (nonneg) pmax(B - gamma[g], 0) else soft_threshold(B, gamma[g])
    if (scale) {
      for (i in seq_along(k)) {
        ad <- drop((sv$v^2) %*% (sv$d^2 / (sv$d^2 + k[i])))
        sc[i, g] <- .scale_of(scale_type, pr$X, pr$y, Th[, i, drop = FALSE], ad, sigma2)
      }
      Th <- sweep(Th, 2, sc[, g], "*")
    }
    Th <- Th / pr$xs
    beta[, , g] <- Th
    a0[, g] <- pr$ym - drop(crossprod(Th, pr$xm))
  }
  structure(list(beta = beta, a0 = a0, k = k, gamma = gamma, scale = sc,
                 ridge = B / pr$xs, nonneg = nonneg,
                 call = match.call()), class = "hr")
}

#' @param object a fitted \code{"hr"} object.
#' @param ik,ig indices of the ridge parameter and threshold to use.
#' @param newx matrix of new predictor values.
#' @param ... unused.
#' @rdname hr
#' @export
coef.hr <- function(object, ik = 1, ig = 1, ...) {
  c(object$a0[ik, ig], object$beta[, ik, ig])
}

#' @rdname hr
#' @export
predict.hr <- function(object, newx, ik = 1, ig = 1, ...) {
  drop(object$a0[ik, ig] + as.matrix(newx) %*% object$beta[, ik, ig])
}

#' Exact finite-sample moments and risk of the HR estimator
#'
#' Under \eqn{Y = X\beta + \epsilon}, \eqn{\epsilon \sim N_n(0, \sigma^2 I_n)}
#' and a fixed design, returns the exact mean, second moment and mean squared
#' error of each coordinate of the HR estimator as an estimator of the
#' projection \eqn{\theta = P_X \beta}, and the total risk
#' \eqn{E\|\hat\theta - \theta\|_2^2}. No centring or scaling is applied:
#' \code{X} is used as supplied. For a fixed scale factor \code{scale = c} the
#' moments are those of \eqn{c\hat\theta}; the scale that minimizes the risk
#' and the minimal risk are also returned.
#'
#' @param X design matrix.
#' @param beta true coefficient vector.
#' @param sigma error standard deviation.
#' @param k ridge parameter.
#' @param gamma threshold.
#' @param nonneg logical, nonnegative variant.
#' @param scale fixed positive scale factor applied to the thresholded
#'   estimator (default one, the unscaled HR estimator).
#' @return A list with components \code{mean}, \code{second}, \code{mse},
#'   \code{risk}, \code{theta}, \code{m} (mean of the ridge estimator),
#'   \code{s} (its coordinatewise standard deviations), \code{scale_opt} (the
#'   risk-minimizing fixed scale) and \code{risk_opt} (the risk at that scale).
#' @importFrom stats dnorm pnorm
#' @export
hr_risk <- function(X, beta, sigma, k, gamma, nonneg = FALSE, scale = 1) {
  if (length(scale) != 1 || scale <= 0) stop("scale must be one positive number")
  sv <- .svd_design(X)
  theta <- drop(sv$v %*% crossprod(sv$v, beta))          # projection onto row space
  shrink <- sv$d^2 / (sv$d^2 + k)
  m <- drop(sv$v %*% (shrink * crossprod(sv$v, theta)))   # E(ridge) = A_k theta
  s <- sigma * sqrt(drop((sv$v^2) %*% (sv$d^2 / (sv$d^2 + k)^2)))
  if (any(s <= 0)) stop("zero column in X: coordinatewise variance vanishes")
  mu1 <- m - gamma                 # mean of Z - gamma
  mu2 <- -m - gamma                # mean of -(Z + gamma)
  # E[W 1{W>0}] and E[W^2 1{W>0}] for W ~ N(mu, s^2)
  e1 <- function(mu) mu * pnorm(mu / s) + s * dnorm(mu / s)
  e2 <- function(mu) (mu^2 + s^2) * pnorm(mu / s) + mu * s * dnorm(mu / s)
  if (nonneg) {
    mean_hr <- e1(mu1)
    second <- e2(mu1)
  } else {
    mean_hr <- e1(mu1) - e1(mu2)
    second <- e2(mu1) + e2(mu2)
  }
  ## Risk as a function of a fixed scale c: c^2 sum(second) - 2 c sum(theta *
  ## mean) + ||theta||^2, minimized at c = sum(theta * mean) / sum(second).
  cross <- sum(theta * mean_hr); tot2 <- sum(second)
  scale_opt <- max(cross / tot2, 0)
  risk_opt <- sum(theta^2) - max(cross, 0)^2 / tot2
  mean_hr <- scale * mean_hr
  second <- scale^2 * second
  mse <- second - 2 * theta * mean_hr + theta^2
  list(mean = mean_hr, second = second, mse = mse, risk = sum(mse),
       theta = theta, m = m, s = s, scale_opt = scale_opt, risk_opt = risk_opt)
}

#' Stein unbiased risk estimate and degrees of freedom of the HR fit
#'
#' For a fixed design without intercept, returns the degrees of freedom
#' \eqn{\sum_{j \in \hat S} (A_k)_{jj}}, with
#' \eqn{A_k = (X^T X + k I)^{-1} X^T X}, and the unbiased estimate of the
#' prediction risk \eqn{E\|X\hat\theta - X\beta\|^2}. When
#' \code{intercept = TRUE} the design and response are centred and one
#' degree of freedom is added for the intercept. For a fixed scale factor
#' \code{scale = c} the fit is \eqn{cX\hat\theta} and its degrees of freedom
#' are \eqn{c} times those of the unscaled fit.
#'
#' @param X design matrix.
#' @param y response.
#' @param sigma2 error variance (known or estimated).
#' @param k ridge parameters.
#' @param gamma thresholds.
#' @param intercept logical.
#' @param standardize logical.
#' @param scale fixed positive scale factor (default one).
#' @return A list with matrices \code{sure} and \code{df} of dimension
#'   \code{length(k) x length(gamma)}, and the matrix \code{scale_min} of the
#'   scale factors that minimize the unbiased risk estimate for each pair of
#'   tuning values.
#' @export
hr_sure <- function(X, y, sigma2, k, gamma, intercept = TRUE,
                    standardize = TRUE, scale = 1) {
  if (length(scale) != 1 || scale <= 0) stop("scale must be one positive number")
  pr <- .prep_design(X, y, intercept, standardize)
  sv <- .svd_design(pr$X)
  n <- nrow(pr$X)
  B <- ridge_path(pr$X, pr$y, k, sv)
  sure <- df <- scale_min <- matrix(NA_real_, length(k), length(gamma))
  for (i in seq_along(k)) {
    akdiag <- drop((sv$v^2) %*% (sv$d^2 / (sv$d^2 + k[i])))
    for (g in seq_along(gamma)) {
      th <- soft_threshold(B[, i], gamma[g])
      act <- th != 0
      fit <- drop(pr$X %*% th)
      df0 <- sum(akdiag[act])
      df[i, g] <- scale * df0 + intercept
      rss <- sum((pr$y - scale * fit)^2)
      sure[i, g] <- rss - n * sigma2 + 2 * sigma2 * df[i, g]
      ## Minimizer over the scale of the unbiased estimate: the least-squares
      ## scale reduced by sigma2 * df0 / ||fit||^2.
      scale_min[i, g] <- if (sum(fit^2) > 0)
        (sum(fit * pr$y) - sigma2 * df0) / sum(fit^2) else NA_real_
    }
  }
  list(sure = sure, df = df, scale_min = scale_min, k = k, gamma = gamma)
}
