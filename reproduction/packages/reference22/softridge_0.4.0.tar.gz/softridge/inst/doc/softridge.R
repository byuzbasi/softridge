## -----------------------------------------------------------------------------
library(softridge)
set.seed(1)
n <- 60; p <- 300
X <- matrix(rnorm(n * p), n, p)
beta <- c(3, -2, 1.5, rep(0, p - 3))
y <- drop(X %*% beta + rnorm(n))

## Cross-validated fit
cv <- cv_hr(X, y, nfolds = 5)
cv$selected

## Scaled HR estimator: the thresholded vector is multiplied by the
## optimism-corrected scale, which corrects the double shrinkage; it needs an
## estimate of the error variance (here the true value)
cvs <- cv_hr(X, y, nfolds = 5, scale = TRUE, sigma2 = 1)
cvs$selected
cvs$scale

## Exact risk of the estimator for given tuning values
hr_risk(scale(X), beta, sigma = 1, k = 10, gamma = 0.05)$risk

