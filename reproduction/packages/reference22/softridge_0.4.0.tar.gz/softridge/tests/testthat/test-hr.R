test_that("ridge path matches the p-dimensional formula", {
  set.seed(1)
  X <- matrix(rnorm(20 * 40), 20, 40); y <- rnorm(20); k <- 3
  b1 <- drop(softridge:::ridge_path(X, y, k))
  b2 <- drop(solve(crossprod(X) + k * diag(40), crossprod(X, y)))
  expect_equal(b1, b2, tolerance = 1e-8)
})

test_that("soft thresholding is correct", {
  expect_equal(soft_threshold(c(-2, -0.5, 0.3, 1.7), 1), c(-1, 0, 0, 0.7))
})

test_that("exact risk agrees with Monte Carlo", {
  set.seed(2)
  n <- 15; p <- 30
  X <- matrix(rnorm(n * p), n, p); beta <- c(2, -1.5, 1, rep(0, p - 3))
  r <- hr_risk(X, beta, sigma = 1, k = 2, gamma = 0.2)
  est <- replicate(4000, {
    y <- X %*% beta + rnorm(n)
    b <- drop(softridge:::ridge_path(X, y, 2))
    sum((soft_threshold(b, 0.2) - r$theta)^2)
  })
  expect_lt(abs(mean(est) - r$risk), 4 * sd(est) / sqrt(length(est)))
})

test_that("hr returns coefficients that reproduce predictions", {
  set.seed(3)
  X <- matrix(rnorm(30 * 60), 30, 60); y <- X[, 1] * 2 + rnorm(30)
  f <- hr(X, y, k = 5, gamma = 0.05)
  expect_equal(length(coef(f)), 61)
  expect_equal(predict(f, X), drop(cbind(1, X) %*% coef(f)))
})

test_that("cv_hr and sure_hr run", {
  set.seed(4)
  X <- matrix(rnorm(40 * 80), 40, 80); y <- X[, 1:2] %*% c(2, -2) + rnorm(40)
  cv <- cv_hr(X, y, nfolds = 4)
  expect_true(length(cv$coef) == 81)
  cvr <- cv_hr(X, y, nfolds = 4, refit = TRUE, max_size = 10)
  expect_true(cvr$size <= 10)
  s <- sure_hr(X, y, sigma2 = 1)
  expect_true(is.finite(s$sure))
})

test_that("least-squares scale minimizes the residual sum of squares", {
  set.seed(5)
  X <- matrix(rnorm(30 * 60), 30, 60); y <- drop(X[, 1:2] %*% c(2, -2) + rnorm(30))
  f0 <- hr(X, y, k = 5, gamma = 0.02)
  f1 <- hr(X, y, k = 5, gamma = 0.02, scale = TRUE, scale_type = "ls")
  cc <- f1$scale[1, 1]
  expect_gt(cc, 1)
  expect_equal(f1$beta[, 1, 1], cc * f0$beta[, 1, 1])
  yc <- y - mean(y); Xc <- scale(X, scale = FALSE)
  rss <- function(a) sum((yc - a * Xc %*% f0$beta[, 1, 1])^2)
  expect_lt(rss(cc), rss(cc * 1.01)); expect_lt(rss(cc), rss(cc * 0.99))
})

test_that("exact risk with a fixed scale agrees with Monte Carlo", {
  set.seed(6)
  n <- 15; p <- 30
  X <- matrix(rnorm(n * p), n, p); beta <- c(2, -1.5, 1, rep(0, p - 3))
  r1 <- hr_risk(X, beta, sigma = 1, k = 2, gamma = 0.2)
  r <- hr_risk(X, beta, sigma = 1, k = 2, gamma = 0.2, scale = r1$scale_opt)
  expect_equal(r$risk, r1$risk_opt)
  expect_lte(r$risk, r1$risk)
  est <- replicate(4000, {
    y <- X %*% beta + rnorm(n)
    b <- drop(softridge:::ridge_path(X, y, 2))
    sum((r1$scale_opt * soft_threshold(b, 0.2) - r$theta)^2)
  })
  expect_lt(abs(mean(est) - r$risk), 4 * sd(est) / sqrt(length(est)))
})

test_that("unbiased risk estimate with a fixed scale is unbiased", {
  set.seed(7)
  n <- 20; p <- 40; cc <- 1.5; k <- 3; g <- 0.1
  X <- matrix(rnorm(n * p), n, p); beta <- c(2, -1.5, 1, rep(0, p - 3))
  mu <- drop(X %*% beta)
  d <- replicate(4000, {
    y <- mu + rnorm(n)
    s <- hr_sure(X, y, 1, k, g, intercept = FALSE, standardize = FALSE, scale = cc)
    b <- drop(softridge:::ridge_path(X, y, k))
    s$sure[1, 1] - sum((cc * X %*% soft_threshold(b, g) - mu)^2)
  })
  expect_lt(abs(mean(d)), 4 * sd(d) / sqrt(length(d)))
})

test_that("scaled cross-validation runs and returns the scale", {
  set.seed(8)
  X <- matrix(rnorm(40 * 80), 40, 80); y <- drop(X[, 1:2] %*% c(2, -2) + rnorm(40))
  cv <- cv_hr(X, y, nfolds = 4, scale = TRUE, sigma2 = 1)
  expect_true(length(cv$coef) == 81)
  expect_true(cv$scale >= 0)
  expect_error(cv_hr(X, y, nfolds = 4, scale = TRUE, refit = TRUE, sigma2 = 1))
  expect_error(cv_hr(X, y, nfolds = 4, scale = TRUE))
  cr <- cv_hr(X, y, nfolds = 4, scale = TRUE, sigma2 = 1, zero_threshold = TRUE)
  expect_equal(cr$gamma, 0)
})

test_that("corrected scale equals the minimizer of the unbiased risk estimate", {
  set.seed(9)
  X <- matrix(rnorm(25 * 50), 25, 50); y <- drop(X[, 1:3] %*% c(2, -1, 1) + rnorm(25))
  s <- hr_sure(X, y, sigma2 = 1, k = 4, gamma = 0.03)
  f <- hr(X, y, k = 4, gamma = 0.03, scale = TRUE, sigma2 = 1)
  expect_equal(f$scale[1, 1], max(s$scale_min[1, 1], 0))
  fl <- hr(X, y, k = 4, gamma = 0.03, scale = TRUE, scale_type = "ls")
  expect_lt(f$scale[1, 1], fl$scale[1, 1])
})

test_that("fold-specific variance estimates are used fold by fold", {
  set.seed(10)
  X <- matrix(rnorm(40 * 80), 40, 80); y <- drop(X[, 1:2] %*% c(2, -2) + rnorm(40))
  fid <- rep(1:4, length.out = 40)
  seen <- list()
  est <- function(X, y, foldid) { seen[[length(seen) + 1]] <<- foldid; var(y) / 4 }
  s2 <- fold_variance(X, y, fid, est)
  expect_length(s2, 5)
  expect_equal(sort(unique(seen[[1]])), 1:3)
  expect_equal(seen[[5]], fid)
  expect_equal(s2[2], var(y[fid != 2]) / 4)
  a <- cv_hr(X, y, foldid = fid, scale = TRUE, sigma2 = rep(0.7, 5))
  b <- cv_hr(X, y, foldid = fid, scale = TRUE, sigma2 = 0.7)
  expect_equal(a$coef, b$coef)
  c1 <- cv_hr(X, y, foldid = fid, scale = TRUE, sigma2 = s2)
  expect_equal(c1$scale, softridge::hr(X, y, k = c1$k, gamma = c1$gamma, scale = TRUE,
                                       sigma2 = s2[5])$scale[1, 1])
  expect_error(cv_hr(X, y, foldid = fid, scale = TRUE, sigma2 = c(1, 1)))
})
